import torch
import torch.utils.data
from torch.utils.data.dataloader import default_collate
from sklearn.model_selection import StratifiedGroupKFold
import pandas

from tqdm import tqdm
import pdb, random
import numpy as np

# class classifier(nn.Module): the model

#def train_one_fold(model, criterion, samevid_loss, samepat_loss, optimizer, data_loader, device)

#def evaluate(model, data_loader, device)

def main(args):
    # Loading data
    whole_dataset = [] # 讀 dataset
    # Creating dataloaders
    data = pandas.read_csv("../labelled-cropped.csv")
    labels = data["label"].tolist() # 直接 assign label array: labels =  [0]*n + [1]*m 之類的
    patients = data["ulabel_pat"].tolist() # patient id 同上: patients = [0]*a + [1]*b + ...
    sgkf = StratifiedGroupKFold(n_splits=5, shuffle=True)

    # create model (略)
    # start training
    print("Start training")
    for epoch in range(args.start_epoch, args.epochs):
        # 一個一個 fold 讀，whole_dataset = 整個 dataset
        for fold, (train_ids, test_ids) in enumerate(sgkf.split(whole_dataset, labels, patients)):
            train_subsampler = torch.utils.data.SubsetRandomSampler(train_ids)  # 挑出這次要用的
            test_subsampler = torch.utils.data.SubsetRandomSampler(test_ids)    # 挑出這次要用的
            train_loader = torch.utils.data.DataLoader(whole_dataset, sampler=train_subsampler, 
                    batch_size=args.batch_size, num_workers=args.workers, drop_last=True) # 實際 load
            test_loader = torch.utils.data.DataLoader(whole_dataset, sampler=test_subsampler,
                    batch_size=args.batch_size, num_workers=args.workers, drop_last=True) # 實際 load

            # train one fold: 等同原本的 epoch
            a,b = train_one_fold(model, criterion, samevid_loss, samepat_loss, optimizer, train_loader, device)